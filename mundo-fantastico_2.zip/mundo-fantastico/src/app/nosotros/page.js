import Navbar   from '@/components/layout/Navbar'
import Footer   from '@/components/layout/Footer'
import Contacto from '@/components/sections/Contacto'
import {
  NosotrosHero,
  Objetivos,
  Vision,
  Mision,
} from '@/components/sections/nosotros/NosotrosSections'
import { getNosotrosImages } from '@/lib/supabase/images'

export const metadata = {
  title: 'Nosotros — Mundo Fantástico',
  description: 'Conoce nuestra misión, visión y objetivos.',
}

// Objeto vacío seguro — usado si Supabase no responde
const EMPTY_IMAGES = {
  hero:      null,
  objetivos: null,
  vision:    null,
  mision:    null,
  todas:     [],
}

export default async function NosotrosPage() {
  // Siempre tiene un valor seguro gracias al fallback
  let images = EMPTY_IMAGES

  try {
    const result = await getNosotrosImages()
    // getNosotrosImages ya retorna EMPTY si falla, pero por seguridad:
    images = result ?? EMPTY_IMAGES
  } catch (err) {
    console.error('[nosotros/page.js] Error cargando imágenes:', err.message)
  }

  return (
    <>
      <Navbar />
      <main className="pt-0">
        {/* Hero — heroImage puede ser null (muestra placeholder) */}
        <NosotrosHero heroImage={images.hero} />

        {/* Objetivos — pasa el array completo (puede ser []) */}
        <Objetivos objetivoImages={images.todas ?? []} />

        {/* Visión */}
        <Vision visionImages={images.todas ?? []} />

        {/* Misión */}
        <Mision misionImages={images.todas ?? []} />

        {/* Formulario */}
        <Contacto />
      </main>
      <Footer />
    </>
  )
}
