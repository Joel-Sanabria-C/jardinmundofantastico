import Navbar   from '@/components/layout/Navbar'
import Footer   from '@/components/layout/Footer'
import Hero     from '@/components/sections/Hero'
import Galeria  from '@/components/sections/Galeria'
import Contacto from '@/components/sections/Contacto'
import { Niveles, QuienesSomos, Metodologia } from '@/components/sections/HomeSections'
import { getGaleriaImages } from '@/lib/supabase/images'

export const metadata = {
  title: 'Mundo Fantástico — Jardín Infantil',
  description: 'Un lugar seguro para crecer y aprender. Educación inicial en Bogotá.',
}

export default async function HomePage() {
  let galeriaImages = []

  try {
    const result = await getGaleriaImages()
    galeriaImages = Array.isArray(result) ? result : []
    console.log(`[page] Galería: ${galeriaImages.length} imágenes desde Supabase`)
  } catch (err) {
    console.error('[page] Error cargando galería:', err.message)
    galeriaImages = []
  }

  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Niveles />
        <QuienesSomos />
        <Galeria images={galeriaImages} />
        <Metodologia />
        <Contacto />
      </main>
      <Footer />
    </>
  )
}
