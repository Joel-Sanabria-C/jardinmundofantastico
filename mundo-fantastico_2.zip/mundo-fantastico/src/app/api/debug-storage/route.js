// src/app/api/debug-storage/route.js
// Visita: http://localhost:3000/api/debug-storage
// ELIMINA este archivo antes de subir a producción

import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const supabase = createClient()
    const BUCKET   = 'fotosjardin'

    // Lista carpetas y archivos en cada ruta
    const probe = async (path) => {
      const { data, error } = await supabase.storage
        .from(BUCKET)
        .list(path, { limit: 30, sortBy: { column: 'name', order: 'asc' } })

      if (error) return { error: error.message, files: [] }

      const carpetas = data?.filter(f => !f.id)            .map(f => f.name) ?? []
      const archivos = data?.filter(f =>  f.id && !f.name.startsWith('.'))
                            .map(f => f.name) ?? []
      return { error: null, carpetas, archivos }
    }

    const [raiz, imagenes, galeriaRaiz, galeriaHome, nosotros] = await Promise.all([
      probe(''),
      probe('imagenes'),
      probe('imagenes/galeria'),
      probe('imagenes/galeria/home'),
      probe('imagenes/nosotros'),
    ])

    // Genera URL pública de ejemplo para verificar acceso
    let urlEjemplo = null
    if (galeriaHome.archivos.length > 0) {
      const { data } = supabase.storage
        .from(BUCKET)
        .getPublicUrl(`imagenes/galeria/home/${galeriaHome.archivos[0]}`)
      urlEjemplo = data.publicUrl
    }

    return NextResponse.json({
      ok:     true,
      bucket: BUCKET,
      rutas: {
        raiz,
        imagenes,
        galeria_raiz: galeriaRaiz,
        galeria_home: galeriaHome,
        nosotros,
      },
      url_ejemplo: urlEjemplo,
    })

  } catch (err) {
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 })
  }
}
