// src/app/api/debug-storage/route.js
// Visita: http://localhost:3000/api/debug-storage
// ELIMINA antes de subir a producción

import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const supabase = createClient()
    const BUCKET = 'fotosmundo fantastico'

    const { data: buckets } = await supabase.storage.listBuckets()
    const bucketNames = buckets?.map(b => b.name) ?? []

    const test = async (path) => {
      const { data, error } = await supabase.storage.from(BUCKET).list(path, { limit: 20 })
      return { files: data?.map(f => f.name) ?? [], error: error?.message ?? null }
    }

    const [root, imagenes, galeriaHome, nosotros] = await Promise.all([
      test(''),
      test('imagenes'),
      test('imagenes/galeria/home'),
      test('imagenes/nosotros'),
    ])

    return NextResponse.json({
      ok: true,
      bucket_buscado: BUCKET,
      bucket_encontrado: bucketNames.includes(BUCKET),
      todos_los_buckets: bucketNames,
      rutas: { root, imagenes, galeria_home: galeriaHome, nosotros },
    })
  } catch (err) {
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 })
  }
}
